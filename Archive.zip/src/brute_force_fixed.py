#!/usr/bin/env python3
"""
Fixed Brute Force Engine - Working Implementation
"""

import hashlib
import itertools
import time

class WorkingBruteForce:
    def __init__(self, target_hash, hash_type='md5'):
        self.target_hash = target_hash
        self.hash_type = hash_type
        self.found = False
        self.result = None
        self.attempts = 0
        self.rate = 0
        self.start_time = None
    
    def hash_password(self, password):
        """Hash password using specified algorithm"""
        password_bytes = password.encode('utf-8')
        if self.hash_type == 'md5':
            return hashlib.md5(password_bytes).hexdigest()
        elif self.hash_type == 'sha1':
            return hashlib.sha1(password_bytes).hexdigest()
        elif self.hash_type == 'sha256':
            return hashlib.sha256(password_bytes).hexdigest()
        elif self.hash_type == 'ntlm':
            return hashlib.md5(password_bytes).hexdigest()[:32]
        else:
            return hashlib.md5(password_bytes).hexdigest()
    
    def expand_charset(self, pattern):
        """Expand mask patterns to actual character sets"""
        charsets = {
            '?l': 'abcdefghijklmnopqrstuvwxyz',
            '?u': 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
            '?d': '0123456789',
            '?s': '!@#$%^&*()_+-=[]{}|;:,.<>?',
            '?a': 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-=[]{}|;:,.<>?'
        }
        
        result = ''
        i = 0
        while i < len(pattern):
            if pattern[i] == '?' and i+1 < len(pattern):
                char_type = pattern[i+1]
                if char_type in charsets:
                    result += charsets[char_type]
                    i += 2
                else:
                    result += pattern[i]
                    i += 1
            else:
                result += pattern[i]
                i += 1
        return result
    
    def brute_force_attack(self, charset_pattern, min_length=1, max_length=4):
        """Working brute force attack"""
        self.start_time = time.time()
        self.found = False
        
        # Expand the charset pattern
        charset = self.expand_charset(charset_pattern)
        
        print(f"[+] Starting brute force attack")
        print(f"[+] Charset pattern: {charset_pattern}")
        print(f"[+] Expanded charset: {charset}")
        print(f"[+] Length range: {min_length}-{max_length}")
        
        # Calculate total combinations for progress tracking
        total_combinations = sum(len(charset) ** length for length in range(min_length, max_length + 1))
        print(f"[+] Total possible combinations: {total_combinations:,}")
        
        for length in range(min_length, max_length + 1):
            print(f"[+] Testing length {length}")
            
            for combination in itertools.product(charset, repeat=length):
                if self.found:
                    return
                
                password = ''.join(combination)
                hashed = self.hash_password(password)
                self.attempts += 1
                
                # Update rate every 1000 attempts
                if self.attempts % 1000 == 0:
                    elapsed = time.time() - self.start_time
                    self.rate = self.attempts / elapsed if elapsed > 0 else 0
                
                # Show progress occasionally
                if self.attempts % 10000 == 0:
                    print(f"[+] Attempts: {self.attempts:,} | Rate: {self.rate:.0f}/sec")
                
                if hashed == self.target_hash:
                    self.result = password
                    self.found = True
                    print(f"[+] 🎉 PASSWORD FOUND: '{password}'")
                    return
        
        print(f"[+] Brute force completed - Password not found")
        self.found = False
    
    def get_stats(self):
        """Get current statistics"""
        return {
            'attempts': self.attempts,
            'rate': self.rate,
            'found': self.found,
            'result': self.result
        }

def test_brute_force():
    """Test the brute force with known passwords"""
    
    # Test 1: Simple 4-letter password
    print("\n🧪 TEST 1: 'test' (4 lowercase letters)")
    test_hash = hashlib.md5('test'.encode()).hexdigest()
    brute = WorkingBruteForce(test_hash, 'md5')
    brute.brute_force_attack('?l?l?l?l', min_length=4, max_length=4)
    
    stats = brute.get_stats()
    print(f"Results: {stats}")
    
    if stats['found']:
        print("✅ SUCCESS: Brute force is working!")
    else:
        print("❌ FAILED: Check the implementation")
    
    return stats['found']

if __name__ == '__main__':
    test_brute_force()
